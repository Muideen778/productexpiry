<?php
$htmlContent ='<html> 
    <head> 
        <title>Onet Nigeria</title> 
    </head> 
    <body> 
<div class=""><div class="aHl"></div><div id=":pm" tabindex="-1"></div><div id=":pb" class="ii gt" jslog="20277; u014N:xr6bB; 4:W251bGwsbnVsbCxbXV0."><div id=":pa" class="a3s aiL "><table id="m_-7294979839915746197m_1419376923311576849backgroundTable" width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff">
	<tbody>
		<tr>
			<td>
				<table width="600" cellspacing="0" cellpadding="0" border="0" align="center">
					<tbody>
						<tr>
							<td width="100%">
								<table style="background:#ffffff;border-bottom:3px solid #499416" width="600" cellspacing="0" cellpadding="0" border="0" align="center">
									<tbody>

										<tr>
											<td style="font-size:1px;line-height:1px" height="20">&nbsp;</td>
										</tr>

										<tr align="center">
											<td>

												<h1> Onet Nigeria</h1>

											</td>
										</tr>

										<tr>
											<td style="font-size:1px;line-height:1px" height="20">&nbsp;</td>
										</tr>

									</tbody>
								</table>
							</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
	</tbody>
</table>
<table id="m_-7294979839915746197m_1419376923311576849backgroundTable" width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff">
	<tbody>
		<tr>
			<td>
				<table style="background:#f6f6f6" width="600" cellspacing="0" cellpadding="0" border="0" align="center">
					<tbody>
						<tr>
							<td width="100%">
								<table width="600" cellspacing="0" cellpadding="0" border="0" align="center">
									<tbody>
										<tr>
											<td style="font-size:1px;line-height:1px" height="20">&nbsp;</td>
										</tr>

										<tr>
											<td>
												<table style="background:#f6f6f6" width="560" cellspacing="0" cellpadding="0" border="0" align="center">
													<tbody align="center">


														<tr>
															<td style="font-size:1px;line-height:1px" width="100%" height="20">&nbsp;</td>
														</tr>


														<tr>
															<td style="font-family:Helvetica,arial,sans-serif;font-size:16px;color:#666666;text-align:left;line-height:30px">
																
Dear '.$usermobile.', <br> '.$mailmessage.'




																<p>Thanks For Choosing <b><a href="https://onetng.com">OnetNg</a></b>.</p>
															</td>
														</tr>

													</tbody>
												</table>
											</td>
										</tr>

										<tr>
											<td style="font-size:1px;line-height:1px" height="20">&nbsp;</td>
										</tr>

									</tbody>
								</table>
							</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
	</tbody>
</table>

</div></div></div><div id=":pq" class="ii gt" style="display:none"><div id=":pr" class="a3s aiL "></div></div><div class="hi"></div></div>
</body>
</html>';

//$to = $memberemail;
//$subject = $mailtitle;
// Get HTML contents from file

// Set content-type for sending HTML email
//$headers = "MIME-Version: 1.0" . "\r\n";
//$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers

//$headers .= "From:support@onetng.com\r\n";

 //if($sendcopy=="no"){
 
 //}else{
 
 //$headers .= 'Cc: onetnigeria@gmail.com' . "\r\n";
 //}
// Send email
//if(mail($to,$subject,$htmlContent,$headers))
//{
  
//}

?>