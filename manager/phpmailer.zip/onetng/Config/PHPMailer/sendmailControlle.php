<?php

require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


//require 'vendor/autoload.php'; // Adjust based on your installation method

$mail = new PHPMailer(true); // Enable exceptions

// SMTP Configuration
$mail->isSMTP();
$mail->Host = 'mbox.freehostia.com'; // Your SMTP server
$mail->SMTPAuth = true;
$mail->Username = 'support@onetng.com'; // Your Mailtrap username
$mail->Password = 'WB0g9Uv8w_'; // Your Mailtrap password
$mail->SMTPSecure = 'tls';
$mail->Port = 465;

// Sender and recipient settings
$mail->setFrom('support@onetng.com', 'Onet Nigeria');
$mail->addAddress('adewumitosk@gmail.com', 'Rasaqour');

// Sending plain text email
$mail->isHTML(false); // Set email format to plain text
$mail->Subject = 'Your Subject Here';
$mail->Body    = 'This is the plain text message body';

// Send the email
if(!$mail->send()){
    echo 'Message could not be sent. Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent';
}