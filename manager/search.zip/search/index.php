<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title>jQuery Search Autocomplete</title>

    <style type="text/css" title="currentStyle">
                @import "css/grid_sytles.css";
                @import "css/themes/smoothness/jquery-ui-1.8.4.custom.css";  
    </style>

    <!-- jQuery libs -->
    <script  type="text/javascript" src="js/jquery-1.6.1.min.js"></script>
    <script  type="text/javascript" src="js/jquery-ui-1.7.custom.min.js"></script>

    <script  type="text/javascript" src="js/jquery-search.js"></script>

</head>
<body>

<div id="container" style="width:100%; margin:0px;">
    <div id="dataTable">

        <div class="ui-grid ui-widget ui-widget-content ui-corner-all">

            <div class="ui-grid-header ui-widget-header ui-corner-top clearfix">

              

                <div class="header-left">
                    Search Item: 
                      <input type="text" placeholder="Enter item to start searching" autofocus id="searchData" style="width: 250px; height:30px;"></div>
                </div>

         
                <div id="results"></div>
          
         <!--   <div class="ui-grid-footer ui-widget-header ui-corner-bottom">
                <div class="grid-results">Results  </div>
            </div> --->
        </div>
    </div>

</div>

</body>
</html>